import React, { useState, useEffect, useMemo } from "react";
import { getRatingsArray } from "./analytics/types";
import { 
  Search, 
  Filter, 
  Download, 
  Mail, 
  FileText, 
  Award, 
  RefreshCw,
  ChevronDown,
  UserCheck,
  Users,
  QrCode,
  X,
  CheckCircle2,
  Loader2,
  Trash2,
  Settings2,
  Eye,
  Send,
  Plus,
  AlertCircle,
  CheckSquare,
  Square,
  FileCheck,
  XCircle,
  Bell
} from "lucide-react";
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  doc, 
  updateDoc,
  getDocs,
  orderBy,
  deleteDoc,
  getDoc
} from "firebase/firestore";
import { db, auth } from "../lib/firebase";
import { Course, Registration } from "../types";
import { cn, formatInstructorName } from "../lib/utils";
import toast from "react-hot-toast";
import { QRCodeSVG } from "qrcode.react";
import Papa from "papaparse";

export const RegistrantsList: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedCourseId, setSelectedCourseId] = useState<string>("");
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterTab, setFilterTab] = useState<"all" | "attended">("all");
  const [showQrModal, setShowQrModal] = useState(false);
  const [showCertModal, setShowCertModal] = useState(false);
  const [certFolderId, setCertFolderId] = useState("");
  const [certRecipients, setCertRecipients] = useState<Registration[]>([]);
  const [certSelectedIds, setCertSelectedIds] = useState<string[]>([]);
  const [certEmailSubject, setCertEmailSubject] = useState("ขอแสดงความยินดี! คุณได้รับใบเกียรติบัตร (Certificate)");
  const [certEmailBody, setCertEmailBody] = useState("ขอบคุณที่เข้าร่วมการอบรมเชิงปฏิบัติการกับเรา\nทางเราขอแสดงความยินดีที่ท่านได้ผ่านการอบรมในหลักสูตรนี้\nโดยท่านสามารถดาวน์โหลดไฟล์เกียรติบัตรที่แนบมาพร้อมกับอีเมลนี้เพื่อเก็บไว้เป็นหลักฐานครับ");
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [isValidatingCert, setIsValidatingCert] = useState(false);
  const [certFolderStats, setCertFolderStats] = useState<{fileCount: number, folderName: string} | null>(null);
  const [isSendingCerts, setIsSendingCerts] = useState(false);
  const [certSendingProgress, setCertSendingProgress] = useState({ current: 0, total: 0 });
  
  const [customCertRecipients, setCustomCertRecipients] = useState<{id: string, name: string, email: string}[]>([]);
  const [newCustomCertName, setNewCustomCertName] = useState("");
  const [newCustomCertEmail, setNewCustomCertEmail] = useState("");
  
  const [instructorMap, setInstructorMap] = useState<Record<string, string>>({});
  const [deleteConfirm, setDeleteConfirm] = useState<{regId: string, courseId: string, sessionId: string | null} | null>(null);
  const [selectedRegIds, setSelectedRegIds] = useState<string[]>([]);
  const [bulkDeleteConfirm, setBulkDeleteConfirm] = useState(false);
  const [isBulkDeleting, setIsBulkDeleting] = useState(false);
  
  // Eval states
  const [showEvalModal, setShowEvalModal] = useState(false);
  const [evalSelectedIds, setEvalSelectedIds] = useState<string[]>([]);
  const [customEvalRecipients, setCustomEvalRecipients] = useState<{id: string, name: string, email: string}[]>([]);
  const [newCustomEvalName, setNewCustomEvalName] = useState("");
  const [newCustomEvalEmail, setNewCustomEvalEmail] = useState("");
  const [evalBaseUrl, setEvalBaseUrl] = useState<string>(
    window.location.origin.includes("run.app") 
      ? "https://..." 
      : window.location.origin
  );
  
  // Reminder states
  const [showReminderModal, setShowReminderModal] = useState(false);
  const [reminderSelectedIds, setReminderSelectedIds] = useState<string[]>([]);
  const [reminderSubject, setReminderSubject] = useState("");
  const [reminderBody, setReminderBody] = useState("");
  const [isSendingReminder, setIsSendingReminder] = useState(false);

  // Fetch instructors for mapping ID
  useEffect(() => {
    const fetchInstructors = async () => {
      try {
        const snap = await getDocs(collection(db, "instructors"));
        const map: Record<string, string> = {};
        snap.docs.forEach(doc => {
          const data = doc.data();
          if (data.email && data.id) {
            map[data.email] = data.id;
          }
        });
        setInstructorMap(map);
      } catch (error) {
        console.error("Error fetching instructors:", error);
      }
    };
    fetchInstructors();
  }, []);

  // Fetch all courses for the dropdown
  useEffect(() => {
    const q = query(collection(db, "courses"), orderBy("date", "asc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setCourses(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Course[]);
    });
    return () => unsubscribe();
  }, []);

  // Fetch registrations when course changes
  useEffect(() => {
    if (!selectedCourseId) {
      setRegistrations([]);
      return;
    }

    setLoading(true);
    const q = query(
      collection(db, "registrations"), 
      where("courseId", "==", selectedCourseId)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const regs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Registration[];
      // Preserve intended registration order: sequenceNumber ascending, fallback to registeredAt
      regs.sort((a, b) => {
        const seqA = a.sequenceNumber || 0;
        const seqB = b.sequenceNumber || 0;
        if (seqA !== seqB) return seqA - seqB;
        return new Date(a.registeredAt || 0).getTime() - new Date(b.registeredAt || 0).getTime();
      });
      setRegistrations(regs);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching registrations:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [selectedCourseId]);

  // Generate continuous display sequence number mapped from sorted active registrations
  // so the running number remains continuous (01, 02, 03...) after cancellations
  // and search/filtering retains each applicant's true continuous position in the course
  const registrationOrderMap = useMemo(() => {
    const map = new Map<string, number>();
    registrations.forEach((reg, index) => {
      map.set(reg.id, index + 1);
    });
    return map;
  }, [registrations]);

  const filteredRegistrations = registrations.filter(reg => {
    const matchesSearch = 
      reg.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      reg.userEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
      reg.userDepartment?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesTab = filterTab === "all" || reg.attended;
    
    return matchesSearch && matchesTab;
  });

  const toggleSelectAll = () => {
    if (selectedRegIds.length === filteredRegistrations.length) {
      setSelectedRegIds([]);
    } else {
      setSelectedRegIds(filteredRegistrations.map(r => r.id));
    }
  };

  const toggleSelectReg = (id: string) => {
    setSelectedRegIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleBulkDelete = async () => {
    if (selectedRegIds.length === 0 || !selectedCourseId) return;
    
    setBulkDeleteConfirm(false);
    setIsBulkDeleting(true);
    const toastId = toast.loading(`กำลังลบ ${selectedRegIds.length} รายการ...`);

    try {
      const courseRef = doc(db, "courses", selectedCourseId);
      const courseDoc = await getDoc(courseRef);
      
      if (!courseDoc.exists()) throw new Error("Course not found");
      const currentCourse = courseDoc.data() as Course;
      let updatedSessions = [...(currentCourse.sessions || [])];
      let enrolledSeats = currentCourse.enrolledSeats || 0;
      let totalRegistrations = currentCourse.totalRegistrations || 0;

      // Group deletions by session to update seats correctly
      const regsToDelete = registrations.filter(r => selectedRegIds.includes(r.id));
      
      for (const reg of regsToDelete) {
        // Delete registration
        await deleteDoc(doc(db, "registrations", reg.id));

        // Update seats logic
        if (reg.sessionId) {
          let sessionIndex = updatedSessions.findIndex(s => s.sessionId === reg.sessionId);
          if (sessionIndex === -1 && updatedSessions.length > 0) sessionIndex = 0;
          if (sessionIndex !== -1 && updatedSessions[sessionIndex].enrolledSeats > 0) {
            updatedSessions[sessionIndex].enrolledSeats -= 1;
          }
        } else {
          if (updatedSessions.length > 0 && updatedSessions[0].enrolledSeats > 0) {
            updatedSessions[0].enrolledSeats -= 1;
          } else if (enrolledSeats > 0) {
            enrolledSeats -= 1;
          }
        }
        totalRegistrations = Math.max(0, totalRegistrations - 1);
      }

      // Update course once
      await updateDoc(courseRef, { 
        sessions: updatedSessions,
        enrolledSeats: enrolledSeats,
        totalRegistrations: totalRegistrations
      });

      setSelectedRegIds([]);
      toast.success(`ลบ ${regsToDelete.length} รายการเรียบร้อยแล้ว`, { id: toastId });
    } catch (error) {
      console.error("Bulk delete error:", error);
      toast.error("เกิดข้อผิดพลาดในการลบข้อมูล", { id: toastId });
    } finally {
      setIsBulkDeleting(false);
    }
  };

  const handleExportCSV = () => {
    if (filteredRegistrations.length === 0) {
      toast.error("ไม่มีข้อมูลให้ส่งออก");
      return;
    }

    const selectedCourse = courses.find(c => c.id === selectedCourseId);
    const data = filteredRegistrations.map((reg, index) => {
      const displaySequenceNumber = registrationOrderMap.get(reg.id) ?? (index + 1);
      return {
        "ลำดับ": displaySequenceNumber,
        "ลำดับการเช็คอิน": reg.checkInSequenceNumber || "-",
        "รหัสอาจารย์": reg.instructorId || instructorMap[reg.userEmail] || "-",
        "ชื่อ-นามสกุล": formatInstructorName(reg.userName),
        "อีเมล": reg.userEmail,
        "หน่วยงาน": reg.userDepartment,
        "ตำแหน่ง": reg.userPosition,
        "สถานะการเข้าอบรม": reg.attended ? "มาอบรมจริง" : "ยังไม่ได้เช็คอิน",
        "เวลาเช็คอิน": reg.checkInAt ? new Date(reg.checkInAt).toLocaleString('th-TH') : "-",
        "วันที่ลงทะเบียน": new Date(reg.registeredAt).toLocaleString('th-TH')
      };
    });

    const csv = Papa.unparse(data);
    const blob = new Blob(["\ufeff" + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `รายชื่อผู้สมัคร_${selectedCourse?.title || 'หลักสูตร'}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success("ส่งออกไฟล์ CSV เรียบร้อยแล้ว");
  };

  const handleReorderSequence = async () => {
    if (!selectedCourseId) {
      toast.error("กรุณาเลือกหลักสูตรก่อน");
      return;
    }
    if (registrations.length === 0) {
      toast.error("ไม่มีผู้ลงทะเบียนในหลักสูตรนี้");
      return;
    }
    
    setLoading(true);
    try {
      // Sort registrations by registeredAt
      const sortedRegs = [...registrations].sort((a, b) => {
        return new Date(a.registeredAt).getTime() - new Date(b.registeredAt).getTime();
      });
      
      // Update each document with a new sequential number
      let seq = 1;
      const updatePromises = sortedRegs.map(reg => {
        return updateDoc(doc(db, "registrations", reg.id), {
          sequenceNumber: seq++
        });
      });
      
      await Promise.all(updatePromises);
      toast.success("ปรับปรุงลำดับที่เรียบร้อยแล้ว");
    } catch (error) {
      console.error("Error reordering sequence:", error);
      toast.error("เกิดข้อผิดพลาดในการปรับปรุงลำดับที่");
    } finally {
      setLoading(false);
    }
  };

  const handleToggleCertRecipient = (regId: string) => {
    setCertSelectedIds(prev => 
      prev.includes(regId) ? prev.filter(id => id !== regId) : [...prev, regId]
    );
  };

  const handleValidateCertFolder = async () => {
    if (!certFolderId) {
      toast.error("กรุณาระบุ Folder ID");
      return;
    }

    // Extract ID if URL is pasted
    let folderId = certFolderId;
    const match = certFolderId.match(/folders\/([a-zA-Z0-9-_]+)/);
    if (match) folderId = match[1];
    else if (certFolderId.includes("id=")) {
      const urlParams = new URLSearchParams(certFolderId.substring(certFolderId.indexOf('?')));
      folderId = urlParams.get("id") || certFolderId;
    }

    setIsValidatingCert(true);
    try {
      // Create a specific GAS URL for Cert system as requested
      const gasUrl = "https://script.google.com/macros/s/AKfycbyk4505Uis2F-0fKsX7X9iuDsrOfB7aPyD_TO00JUq_BMi9ZDUBzjSKFOFsNHrSVVxN/exec";
      
      const response = await fetch(gasUrl, {
        method: "POST",
        mode: "no-cors",
        headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify({ action: "validate_folder", folderId })
      });
      
      // Since it's no-cors, we can't get result. We assume it's okay for now or 
      // the user will see error eventually. 
      // Actually, for better UX, I'll advise the user that validation is triggered 
      // but due to CORS they should proceed if they are sure.
      setCertFolderStats({ fileCount: certRecipients.length, folderName: "โฟลเดอร์ที่ระบุ" });
      setIsPreviewMode(true);
    } catch (error) {
      toast.error("ไม่สามารถตรวจสอบโฟลเดอร์ได้");
    } finally {
      setIsValidatingCert(false);
    }
  };

  const handleSendCertificates = async (isTest = false) => {
    if (!selectedCourseId) {
      toast.error("กรุณาเลือกหลักสูตรก่อน");
      return;
    }

    const selectedRecipientsFromRegistrations = certRecipients.filter(r => certSelectedIds.includes(r.id));
    const selectedCustomRecipients = customCertRecipients.filter(r => certSelectedIds.includes(r.id));

    if (selectedRecipientsFromRegistrations.length === 0 && selectedCustomRecipients.length === 0 && !isTest) {
      toast.error("ไม่มีรายชื่อผู้รับในรายการ");
      return;
    }
    
    if (!certFolderId) {
      toast.error("กรุณาระบุ Folder ID");
      return;
    }

    // Extract ID
    let folderId = certFolderId;
    const folderMatch = certFolderId.match(/folders\/([a-zA-Z0-9-_]+)/);
    if (folderMatch) folderId = folderMatch[1];

    const selectedCourse = courses.find(c => c.id === selectedCourseId);
    
    // Combine regular recipients and custom ones
    const allSelectedRecipients = [
      ...selectedRecipientsFromRegistrations.map(r => {
        const globalIndex = certRecipients.findIndex(cr => cr.id === r.id);
        return {
          email: r.userEmail,
          name: formatInstructorName(r.userName),
          sequence: globalIndex + 1
        };
      }),
      ...selectedCustomRecipients.map(r => {
        const customIndex = customCertRecipients.findIndex(ccr => ccr.id === r.id);
        return {
          email: r.email,
          name: formatInstructorName(r.name),
          sequence: certRecipients.length + customIndex + 1
        };
      })
    ];

    // For test send, use currently logged in admin email
    const recipients = isTest ? [{
      email: auth.currentUser?.email || "test@admin.com",
      name: "แอดมิน (ทดสอบ)",
      sequence: 1
    }] : allSelectedRecipients;

    const payload = {
      action: isTest ? "test_send" : "send_certificates",
      folderId: folderId,
      courseTitle: selectedCourse?.title || "หลักสูตรอบรม",
      emailSubject: certEmailSubject,
      emailBody: certEmailBody,
      recipients: recipients
    };

    const gasUrl = "https://script.google.com/macros/s/AKfycbyk4505Uis2F-0fKsX7X9iuDsrOfB7aPyD_TO00JUq_BMi9ZDUBzjSKFOFsNHrSVVxN/exec";

    try {
      setIsSendingCerts(true);
      toast.loading(isTest ? "กำลังส่งอีเมลทดสอบ..." : "กำลังเริ่มการส่งใบ Certificate...", { id: "cert_op" });
      
      await fetch(gasUrl, {
        method: "POST",
        mode: "no-cors",
        headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify(payload)
      });

      if (!isTest) {
        // Update Firestore status for all selected
        const updatePromises = selectedRecipientsFromRegistrations.map(r => 
          updateDoc(doc(db, "registrations", r.id), {
            certStatus: 'sent',
            certSentAt: new Date().toISOString()
          })
        );
        await Promise.all(updatePromises);
      }

      toast.success(isTest ? "ส่งอีเมลทดสอบเรียบร้อยแล้ว" : "ระบบรับคำสั่งส่ง Certificate เรียบร้อยแล้ว", { id: "cert_op" });
      if (!isTest) setShowCertModal(false);
    } catch (error) {
      console.error(error);
      toast.error("เกิดข้อผิดพลาดในการดำเนินการ", { id: "cert_op" });
    } finally {
      setIsSendingCerts(false);
    }
  };

  const handleExportEvals = async () => {
    if (!selectedCourseId) {
      toast.error("กรุณาเลือกหลักสูตรก่อน");
      return;
    }

    try {
      toast.loading("กำลังดึงข้อมูลประเมินผล...", { id: "export_eval" });
      const evalsSnap = await getDocs(query(collection(db, "evaluations"), where("courseId", "==", selectedCourseId)));
      
      if (evalsSnap.empty) {
        toast.error("ยังไม่มีข้อมูลการประเมินสำหรับหลักสูตรนี้", { id: "export_eval" });
        return;
      }

      const selectedCourse = courses.find(c => c.id === selectedCourseId);
      const data = evalsSnap.docs.map((d, index) => {
        const evalData = d.data();
        let row: any = {
          "ลำดับ": index + 1,
          "ชื่อ-นามสกุล": formatInstructorName(evalData.userName),
          "อีเมล": evalData.userEmail,
          "เวลาประเมิน": new Date(evalData.createdAt).toLocaleString('th-TH')
        };
        // Add ratings
        const ratingsArray = getRatingsArray(evalData.ratings);
        for (let i = 0; i < 10; i++) {
          row[`ข้อที่ ${i+1}`] = ratingsArray[i] || "-";
        }
        row["ข้อเสนอแนะ"] = evalData.suggestion || "-";
        return row;
      });

      const csv = Papa.unparse(data);
      const blob = new Blob(["\ufeff" + csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", `ผลประเมิน_${selectedCourse?.title || 'หลักสูตร'}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast.success("ดาวน์โหลดผลประเมินเรียบร้อยแล้ว", { id: "export_eval" });
    } catch (err) {
      console.error(err);
      toast.error("เกิดข้อผิดพลาดในการดาวน์โหลดผลประเมิน", { id: "export_eval" });
    }
  };

  const handleExportAttendees = () => {
    if (!selectedCourseId) {
      toast.error("กรุณาเลือกหลักสูตรก่อน");
      return;
    }

    const attendees = registrations
      .filter(r => r.attended)
      .sort((a, b) => (a.checkInSequenceNumber || a.sequenceNumber || 0) - (b.checkInSequenceNumber || b.sequenceNumber || 0));

    if (attendees.length === 0) {
      toast.error("ไม่มีผู้เข้าร่วมอบรมที่เช็คอินแล้ว");
      return;
    }

    const selectedCourse = courses.find(c => c.id === selectedCourseId);
    
    const data = attendees.map((reg, index) => ({
      "ลำดับที่ (ใบประกาศ)": index + 1,
      "ลำดับการเช็คอิน": reg.checkInSequenceNumber || "-",
      "ลำดับ (ระบบ)": reg.sequenceNumber,
      "รหัสอาจารย์": reg.instructorId || instructorMap[reg.userEmail] || "-",
      "ชื่อ-นามสกุล": formatInstructorName(reg.userName),
      "อีเมล": reg.userEmail,
      "หน่วยงาน": reg.userDepartment,
      "ตำแหน่ง": reg.userPosition,
      "เวลาเช็คอิน": reg.checkInAt ? new Date(reg.checkInAt).toLocaleString('th-TH') : "-"
    }));

    const csv = Papa.unparse(data);
    const blob = new Blob(["\ufeff" + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `รายชื่อผู้มาอบรมจริง_${selectedCourse?.title || 'หลักสูตร'}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success("ส่งออกรายชื่อผู้มาอบรมจริงเรียบร้อยแล้ว");
  };

  const handleToggleEvalRecipient = (regId: string) => {
    setEvalSelectedIds(prev => 
      prev.includes(regId) ? prev.filter(id => id !== regId) : [...prev, regId]
    );
  };
  
  const handleToggleReminderRecipient = (regId: string) => {
    setReminderSelectedIds(prev => 
      prev.includes(regId) ? prev.filter(id => id !== regId) : [...prev, regId]
    );
  };

  const handleSendReminders = async (isTest = false) => {
    if (!selectedCourseId) {
      toast.error("กรุณาเลือกหลักสูตรก่อน");
      return;
    }

    const selectedRegs = registrations.filter(r => reminderSelectedIds.includes(r.id));

    if (selectedRegs.length === 0 && !isTest) {
      toast.error("กรุณาเลือกผู้รับอย่างน้อย 1 คน");
      return;
    }
    
    if (!reminderSubject.trim() || !reminderBody.trim()) {
      toast.error("กรุณาระบุหัวข้อและเนื้อหาอีเมล");
      return;
    }

    const selectedCourse = courses.find(c => c.id === selectedCourseId);
    
    const recipients = isTest ? [{
      email: auth.currentUser?.email || "test@admin.com",
      name: "แอดมิน (ทดสอบ)"
    }] : selectedRegs.map(r => ({
      email: r.userEmail,
      name: formatInstructorName(r.userName)
    }));

    const payload = {
      action: isTest ? "test_send_reminders" : "send_reminders",
      subject: reminderSubject,
      body: reminderBody,
      courseTitle: selectedCourse?.title || "หลักสูตรอบรม",
      recipients: recipients
    };

    // ใช้ URL สำหรับระบบ Reminder
    const gasUrl = "https://script.google.com/macros/s/AKfycbyk4505Uis2F-0fKsX7X9iuDsrOfB7aPyD_TO00JUq_BMi9ZDUBzjSKFOFsNHrSVVxN/exec";

    try {
      setIsSendingReminder(true);
      toast.loading(isTest ? "กำลังส่งอีเมลทดสอบ..." : "กำลังส่งอีเมลแจ้งเตือน...", { id: "send_rem" });
      
      await fetch(gasUrl, {
        method: "POST",
        mode: "no-cors",
        headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify(payload)
      });

      toast.success(isTest ? "ส่งอีเมลทดสอบเรียบร้อยแล้ว" : "ระบบรับคำสั่งส่งอีเมลแจ้งเตือนเรียบร้อยแล้ว", { id: "send_rem" });
      if (!isTest) setShowReminderModal(false);
    } catch (error) {
      console.error(error);
      toast.error("เกิดข้อผิดพลาดในการดำเนินการ", { id: "send_rem" });
    } finally {
      setIsSendingReminder(false);
    }
  };

  const handleSendEvaluations = async () => {
    if (!selectedCourseId) {
      toast.error("กรุณาเลือกหลักสูตรก่อน");
      return;
    }

    if (evalSelectedIds.length === 0 && customEvalRecipients.length === 0) {
      toast.error("ไม่มีผู้รับลิงก์ประเมินผลในรายการ");
      return;
    }
    
    const selectedCourse = courses.find(c => c.id === selectedCourseId);
    // Construct the absolute evaluation URL.
    const encodedTitle = encodeURIComponent(selectedCourse?.title || "");
    const safeBaseUrl = evalBaseUrl === "https://..." ? "https://ais-pre-sly2upsojdu5nc47xldytg-166049909817.asia-east1.run.app" : evalBaseUrl;
    const evalLink = `${safeBaseUrl.replace(/\/$/, "")}${window.location.pathname.replace(/\/$/, "")}/#/evaluate/${selectedCourseId}?title=${encodedTitle}`;

    const attendeeRecipients = registrations
      .filter(r => evalSelectedIds.includes(r.id))
      .map(r => ({
        email: r.userEmail,
        name: formatInstructorName(r.userName)
      }));

    const customRecipients = customEvalRecipients.map(r => ({
      email: r.email,
      name: r.name
    }));

    const recipients = [...attendeeRecipients, ...customRecipients];

    const payload = {
      action: "send_evaluations",
      courseTitle: selectedCourse?.title || "หลักสูตรอบรม",
      evalLink: evalLink,
      recipients: recipients
    };

    const gasUrl = "https://script.google.com/macros/s/AKfycbyk4505Uis2F-0fKsX7X9iuDsrOfB7aPyD_TO00JUq_BMi9ZDUBzjSKFOFsNHrSVVxN/exec";

    try {
      toast.loading("กำลังส่งอีเมลลิงก์ประเมินผล...", { id: "send_eval" });
      console.log("Sending evaluations payload:", payload);
      
      const response = await fetch(gasUrl, {
        method: "POST",
        mode: "no-cors",
        headers: {
          "Content-Type": "text/plain;charset=utf-8",
        },
        body: JSON.stringify(payload)
      });
      
      console.log("GAS Response (Opaque due to no-cors):", response);
      toast.success(`ส่งลิงก์ประเมินผลสำเร็จ (${recipients.length} คน) กรุณาตรวจสอบอีเมลผู้รับ`, { id: "send_eval" });
      setShowEvalModal(false);
      setCustomEvalRecipients([]); // Clear custom ones after success
    } catch (error) {
      console.error("Error sending evaluations:", error);
      toast.error("เกิดข้อผิดพลาดในการส่ง", { id: "send_eval" });
    }
  };

  const handleAction = (action: string) => {
    if (!selectedCourseId) {
      toast.error("กรุณาเลือกหลักสูตรก่อน");
      return;
    }
    toast.success(`ระบบกำลังดำเนินการ: ${action}`);
  };

  const toggleAttendance = async (regId: string, currentStatus: boolean) => {
    try {
      if (!currentStatus) {
        // Checking in
        const maxCheckInSeq = registrations.reduce((max, reg) => {
           return (reg.checkInSequenceNumber || 0) > max ? (reg.checkInSequenceNumber || 0) : max;
        }, 0);
        
        await updateDoc(doc(db, "registrations", regId), {
          attended: true,
          checkInAt: new Date().toISOString(),
          checkInSequenceNumber: maxCheckInSeq + 1
        });
        toast.success("เช็คอินเรียบร้อย");
      } else {
        // Un-checking in
        await updateDoc(doc(db, "registrations", regId), {
          attended: false,
          checkInAt: null,
          checkInSequenceNumber: null
        });
        toast.success("ยกเลิกการเช็คอิน");
      }
    } catch (error) {
      toast.error("เกิดข้อผิดพลาด");
    }
  };

  const handleDeleteClick = (regId: string, courseId: string, sessionId: string | null) => {
    setDeleteConfirm({ regId, courseId, sessionId });
  };

  const confirmDeleteRegistration = async () => {
    if (!deleteConfirm) return;
    const { regId, courseId, sessionId } = deleteConfirm;
    setDeleteConfirm(null);

    try {
      // 1. Delete registration doc
      await deleteDoc(doc(db, "registrations", regId));

      // 2. Update course seats
      const courseRef = doc(db, "courses", courseId);
      const courseDoc = await getDoc(courseRef);
      if (courseDoc.exists()) {
        const currentCourse = courseDoc.data() as Course;
        let updatedSessions = [...(currentCourse.sessions || [])];
        let enrolledSeats = currentCourse.enrolledSeats || 0;
        let totalRegistrations = currentCourse.totalRegistrations || 0;
        
        if (sessionId) {
          let sessionIndex = updatedSessions.findIndex(s => s.sessionId === sessionId);
          
          // If session ID not found (orphaned), default to the first session if available
          if (sessionIndex === -1 && updatedSessions.length > 0) {
            sessionIndex = 0;
          }

          if (sessionIndex !== -1 && updatedSessions[sessionIndex].enrolledSeats > 0) {
            updatedSessions[sessionIndex].enrolledSeats -= 1;
          }
        } else {
          // Legacy course or single session
          if (updatedSessions.length > 0 && updatedSessions[0].enrolledSeats > 0) {
            updatedSessions[0].enrolledSeats -= 1;
          } else if (enrolledSeats > 0) {
            enrolledSeats -= 1;
          }
        }

        // Also decrement totalRegistrations to keep it in sync
        totalRegistrations = Math.max(0, totalRegistrations - 1);
        
        await updateDoc(courseRef, { 
          sessions: updatedSessions,
          enrolledSeats: enrolledSeats,
          totalRegistrations: totalRegistrations
        });
      }

      toast.success("ลบผู้ลงทะเบียนเรียบร้อยแล้ว");
    } catch (error) {
      console.error("Error deleting registration:", error);
      toast.error("เกิดข้อผิดพลาดในการลบผู้ลงทะเบียน");
    }
  };

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-2">
          <h1 className="text-[28px] lg:text-[32px] font-bold text-[#333333] tracking-[0.02em] leading-[1.6]">
            รายชื่อ<br />ผู้ลงทะเบียน
          </h1>
          <p className="text-[#4A4A4A] font-normal text-[14px] lg:text-[16px] max-w-xs leading-[1.7]">
            ตรวจสอบและจัดการรายชื่ออาจารย์ที่สมัครเข้าร่วมอบรม
          </p>
        </div>

        {/* Action Buttons Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          <button 
            onClick={() => {
              if (!selectedCourseId) {
                toast.error("กรุณาเลือกหลักสูตรก่อน");
                return;
              }
              const attendees = registrations
                .filter(r => r.attended)
                .sort((a, b) => (a.checkInSequenceNumber || a.sequenceNumber || 0) - (b.checkInSequenceNumber || b.sequenceNumber || 0));
              
              if (attendees.length === 0) {
                toast.error("ไม่มีผู้เข้าร่วมอบรมที่เช็คอินแล้ว");
                return;
              }
              setCertRecipients(attendees);
              setCertSelectedIds(attendees.map(a => a.id));
              setCustomCertRecipients([]); // Reset custom recipients
              setIsPreviewMode(false);
              setCertFolderStats(null);
              setShowCertModal(true);
            }}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-[#4A4A4A] rounded-xl text-[13px] font-medium transition-all border border-slate-200"
          >
            <Award className="w-4 h-4" />
            ส่งใบ Certificate
          </button>
          <button 
            onClick={() => {
              if (!selectedCourseId) {
                toast.error("กรุณาเลือกหลักสูตรก่อน");
                return;
              }
              const allRegs = registrations;
              if (allRegs.length === 0) {
                toast.error("ไม่มีผู้ลงทะเบียนในหลักสูตรนี้");
                return;
              }
              
              const currentCourse = courses.find(c => c.id === selectedCourseId);
              
              setReminderSelectedIds(allRegs.map(r => r.id));
              setReminderSubject(`[แจ้งเตือนการอบรม] เตรียมความพร้อมก่อนเข้าร่วมอบรมหลักสูตร: ${currentCourse?.title || ''}`);
              
              const dateStr = currentCourse?.date 
                ? new Date(currentCourse.date).toLocaleDateString('th-TH', { year: 'numeric', month: 'long', day: 'numeric'}) 
                : 'ไม่ระบุวัน';
              
              setReminderBody(`ขอแจ้งเตือนการเข้าร่วมอบรมเชิงปฏิบัติการหลักสูตร "${currentCourse?.title || ''}"\n\nซึ่งจะจัดขึ้นในวันที่ ${dateStr} เวลา ${currentCourse?.startTime || '-'} น. ถึง ${currentCourse?.endTime || '-'} น.\nสถานที่: ${currentCourse?.locationDetail || 'ไม่ระบุ'}\nวิทยากร: ${currentCourse?.instructorName || '-'}\n\nกรุณาเตรียมตัวและมาตรงตามเวลาที่กำหนด เพื่อรักษาประโยชน์สูงสุดในการอบรมครั้งนี้ครับ/ค่ะ\nหากมีข้อสงสัยเพิ่มเติม สามารถติดต่อสอบถามได้ที่สำนักพัฒนาการเรียนรู้`);
              
              setShowReminderModal(true);
            }}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-[#4A4A4A] rounded-xl text-[13px] font-medium transition-all border border-slate-200"
          >
            <Bell className="w-4 h-4" />
            ส่งอีเมลแจ้งเตือน
          </button>
          <button 
            onClick={() => {
              if (!selectedCourseId) {
                toast.error("กรุณาเลือกหลักสูตรก่อน");
                return;
              }
              const attendees = registrations.filter(r => r.attended);
              if (attendees.length === 0) {
                toast.error("ไม่มีผู้เข้าร่วมอบรมที่เช็คอินแล้ว");
                return;
              }
              setEvalSelectedIds(attendees.map(a => a.id));
              setShowEvalModal(true);
            }}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-[#4A4A4A] rounded-xl text-[13px] font-medium transition-all border border-slate-200"
          >
            <FileText className="w-4 h-4" />
            ส่งแบบประเมินผล
          </button>
          <button 
            onClick={handleExportAttendees}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-[#4A4A4A] rounded-xl text-[13px] font-medium transition-all border border-slate-200"
          >
            <Download className="w-4 h-4" />
            ดาวน์โหลดที่มาอบรมจริง
          </button>
          <button 
            onClick={handleExportEvals}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-[#4A4A4A] rounded-xl text-[13px] font-medium transition-all border border-slate-200"
          >
            <Download className="w-4 h-4" />
            ดาวน์โหลดผลประเมิน
          </button>
          <div className="flex bg-slate-100 rounded-xl p-1 border border-slate-200">
            <button 
              onClick={() => setFilterTab("all")}
              className={cn(
                "flex-1 px-3 py-1.5 rounded-lg text-[12px] font-medium transition-all",
                filterTab === "all" ? "bg-crimson text-white shadow-sm" : "text-slate-500 hover:text-slate-700"
              )}
            >
              ทั้งหมด
            </button>
            <button 
              onClick={() => setFilterTab("attended")}
              className={cn(
                "flex-1 px-3 py-1.5 rounded-lg text-[12px] font-medium transition-all",
                filterTab === "attended" ? "bg-crimson text-white shadow-sm" : "text-slate-500 hover:text-slate-700"
              )}
            >
              มาอบรมจริง
            </button>
          </div>
          <button 
            onClick={handleExportCSV}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-[#4A4A4A] rounded-xl text-[13px] font-medium transition-all border border-slate-200"
          >
            <Download className="w-4 h-4" />
            ส่งออก รายชื่อสมัคร (CSV)
          </button>
          <button 
            onClick={handleReorderSequence}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-[#4A4A4A] rounded-xl text-[13px] font-medium transition-all border border-slate-200"
          >
            <RefreshCw className="w-4 h-4" />
            ปรับปรุงลำดับที่
          </button>
          {selectedCourseId && (
            <button 
              onClick={() => setShowQrModal(true)}
              className="flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 rounded-xl text-[13px] font-medium transition-all border border-indigo-100"
            >
              <QrCode className="w-4 h-4" />
              QR Code Check-in
            </button>
          )}
          {selectedRegIds.length > 0 && (
            <button 
              onClick={() => setBulkDeleteConfirm(true)}
              className="flex items-center justify-center gap-2 px-4 py-2.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl text-[13px] font-bold transition-all border border-red-100 shadow-sm"
            >
              <Trash2 className="w-4 h-4" />
              ลบที่เลือก ({selectedRegIds.length})
            </button>
          )}
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm flex flex-col lg:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
          <input 
            type="text"
            placeholder="ค้นหาชื่อ, รหัส หรือหน่วยงาน..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-crimson outline-none transition-all font-normal text-[14px] lg:text-[16px] text-[#4A4A4A]"
          />
        </div>
        
        <div className="flex items-center gap-4 w-full lg:w-auto">
          <div className="relative flex-1 lg:w-80">
            <Filter className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <select 
              value={selectedCourseId}
              onChange={(e) => setSelectedCourseId(e.target.value)}
              className="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-crimson outline-none transition-all font-medium text-[14px] lg:text-[16px] appearance-none text-[#333333]"
            >
              <option value="">-- กรุณาเลือกหลักสูตร --</option>
              <option value="all_courses">ทุกหลักสูตร</option>
              {courses.map(course => (
                <option key={course.id} value={course.id}>{course.title} (วันที่อบรม: {course.date})</option>
              ))}
            </select>
            <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          </div>
          <div className="text-slate-400 text-[12px] lg:text-[13px] font-medium uppercase tracking-widest whitespace-nowrap">
            พบ {filteredRegistrations.length} รายการ
          </div>
        </div>
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-xl overflow-hidden min-h-[400px]">
        {!selectedCourseId ? (
          <div className="h-[400px] flex flex-col items-center justify-center text-center p-12">
            <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6">
              <Filter className="w-8 h-8 text-slate-200" />
            </div>
            <h3 className="text-[20px] lg:text-[24px] font-semibold text-[#333333] mb-2 tracking-[0.02em]">กรุณาเลือกหลักสูตรเพื่อดูรายชื่อ</h3>
            <p className="text-[#4A4A4A] font-normal text-[14px] lg:text-[16px]">เลือกจากเมนู "กรองตามหลักสูตร" ด้านบน</p>
          </div>
        ) : loading ? (
          <div className="h-[400px] flex items-center justify-center">
            <Loader2 className="w-10 h-10 text-crimson animate-spin" />
          </div>
        ) : filteredRegistrations.length === 0 ? (
          <div className="h-[400px] flex flex-col items-center justify-center text-center p-12">
            <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6">
              <Users className="w-8 h-8 text-slate-200" />
            </div>
            <h3 className="text-[20px] lg:text-[24px] font-semibold text-[#333333] mb-2 tracking-[0.02em]">ไม่พบรายชื่อผู้สมัคร</h3>
            <p className="text-[#4A4A4A] font-normal text-[14px] lg:text-[16px]">ยังไม่มีผู้ลงทะเบียนในหลักสูตรนี้ หรือไม่พบข้อมูลที่ค้นหา</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/50 border-b border-slate-100">
                  <th className="px-6 py-5 text-center w-12">
                    <input 
                      type="checkbox"
                      checked={selectedRegIds.length === filteredRegistrations.length && filteredRegistrations.length > 0}
                      onChange={toggleSelectAll}
                      className="w-4 h-4 rounded text-crimson focus:ring-crimson cursor-pointer border-slate-300"
                    />
                  </th>
                  <th className="px-8 py-5 text-[12px] lg:text-[13px] font-medium text-slate-400 uppercase tracking-[0.2em]">ลำดับสมัคร</th>
                  <th className="px-8 py-5 text-[12px] lg:text-[13px] font-medium text-slate-400 uppercase tracking-[0.2em]">ลำดับเช็คอิน</th>
                  <th className="px-6 py-5 text-[12px] lg:text-[13px] font-medium text-slate-400 uppercase tracking-[0.2em]">รหัสอาจารย์</th>
                  <th className="px-6 py-5 text-[12px] lg:text-[13px] font-medium text-slate-400 uppercase tracking-[0.2em]">ชื่อ-นามสกุล</th>
                  <th className="px-6 py-5 text-[12px] lg:text-[13px] font-medium text-slate-400 uppercase tracking-[0.2em]">หน่วยงาน</th>
                  <th className="px-6 py-5 text-[12px] lg:text-[13px] font-medium text-slate-400 uppercase tracking-[0.2em]">อีเมล</th>
                  <th className="px-8 py-5 text-[12px] lg:text-[13px] font-medium text-slate-400 uppercase tracking-[0.2em] text-center">สถานะ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filteredRegistrations.map((reg, index) => {
                  const displaySequenceNumber = registrationOrderMap.get(reg.id) ?? (index + 1);
                  return (
                    <tr key={reg.id} className="hover:bg-slate-50/50 transition-colors group">
                      <td className="px-6 py-4 text-center">
                        <input 
                          type="checkbox"
                          checked={selectedRegIds.includes(reg.id)}
                          onChange={() => toggleSelectReg(reg.id)}
                          className="w-4 h-4 rounded text-crimson focus:ring-crimson cursor-pointer border-slate-300"
                        />
                      </td>
                      <td className="px-8 py-4">
                        <span className="text-[14px] lg:text-[16px] font-bold text-slate-300 group-hover:text-crimson transition-colors">
                          {String(displaySequenceNumber).padStart(2, '0')}
                        </span>
                      </td>
                    <td className="px-8 py-4">
                      {reg.checkInSequenceNumber ? (
                        <span className="text-[14px] lg:text-[16px] font-bold text-emerald-500">
                          {String(reg.checkInSequenceNumber).padStart(2, '0')}
                        </span>
                      ) : (
                        <span className="text-[14px] lg:text-[16px] font-bold text-slate-200">
                          -
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-[12px] lg:text-[13px] font-mono font-medium text-slate-400">
                        {reg.instructorId || instructorMap[reg.userEmail] || "-"}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className="text-[14px] lg:text-[16px] font-normal text-[#333333]">{formatInstructorName(reg.userName)}</span>
                        <span className="text-[12px] text-slate-400 font-medium uppercase tracking-wider">{reg.userPosition}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-[12px] lg:text-[13px] font-medium text-[#4A4A4A] bg-slate-100 px-3 py-1 rounded-full">
                        {reg.userDepartment}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-[12px] lg:text-[13px] font-normal text-slate-400">{reg.userEmail}</span>
                    </td>
                    <td className="px-8 py-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button 
                          onClick={() => toggleAttendance(reg.id, reg.attended)}
                          className={cn(
                            "inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-[12px] font-medium uppercase tracking-widest transition-all",
                            reg.attended 
                              ? "bg-emerald-50 text-emerald-600 border border-emerald-100" 
                              : "bg-slate-50 text-slate-400 border border-slate-100 hover:border-crimson/30 hover:text-crimson"
                          )}
                        >
                          {reg.attended ? (
                            <>
                              <CheckCircle2 className="w-3 h-3" />
                              มาอบรมจริง
                            </>
                          ) : (
                            <>
                              <RefreshCw className="w-3 h-3" />
                              ยังไม่ได้เช็คอิน
                            </>
                          )}
                        </button>
                        <button
                          onClick={() => handleDeleteClick(reg.id, reg.courseId, reg.sessionId || null)}
                          className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors"
                          title="ลบผู้ลงทะเบียน"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* QR Code Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            onClick={() => setShowQrModal(false)}
          />
          <div className="relative bg-white rounded-[3rem] shadow-2xl p-12 max-w-md w-full text-center">
            <button 
              onClick={() => setShowQrModal(false)}
              className="absolute top-8 right-8 p-2 hover:bg-slate-100 rounded-full transition-colors"
            >
              <X className="w-6 h-6 text-slate-300" />
            </button>
            
            <div className="mb-8">
              <div className="w-20 h-20 bg-indigo-50 rounded-3xl flex items-center justify-center mx-auto mb-6">
                <QrCode className="w-10 h-10 text-indigo-600" />
              </div>
              <h3 className="text-2xl font-black text-slate-900 tracking-tight mb-2">QR Code Check-in</h3>
              <p className="text-slate-500 font-medium text-sm">
                ให้ผู้เข้าอบรมสแกน QR Code นี้เพื่อยืนยันการเข้าอบรม
              </p>
            </div>

            <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100 mb-8 flex justify-center">
              <QRCodeSVG 
                value={`${window.location.href.split('#')[0].replace(/\/$/, '')}/#/checkin/${selectedCourseId}`}
                size={200}
                level="H"
                includeMargin={true}
              />
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100">
                <p className="text-xs text-amber-700 font-bold leading-relaxed">
                  * ผู้เข้าอบรมต้องเข้าสู่ระบบด้วย @bu.ac.th ก่อนสแกนเพื่อบันทึกข้อมูล
                </p>
              </div>
              <button 
                onClick={() => window.print()}
                className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl hover:bg-slate-800 transition-all shadow-lg"
              >
                พิมพ์ QR Code
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Certificate Modal */}
      {showCertModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            onClick={() => { if (!isSendingCerts) setShowCertModal(false); }}
          />
          <div className="relative bg-white rounded-3xl shadow-2xl p-6 md:p-8 max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden">
            <div className="flex justify-between items-center mb-6 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center">
                  <Award className="w-5 h-5 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900">ระบบส่งใบ Certificate</h3>
                  <p className="text-xs text-slate-500 font-medium">ขั้นตอนที่ {isPreviewMode ? "2: ตรวจสอบและยืนยัน" : "1: ตั้งค่าและเลือกผู้รับ"}</p>
                </div>
              </div>
              {!isSendingCerts && (
                <button 
                  onClick={() => setShowCertModal(false)}
                  className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              )}
            </div>

            <div className="flex-1 overflow-y-auto pr-2 space-y-6">
              {!isPreviewMode ? (
                /* Step 1: Configuration */
                <div className="space-y-6">
                  {/* Folder ID Input */}
                  <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200">
                    <div className="flex items-center gap-2 mb-3">
                      <Settings2 className="w-4 h-4 text-indigo-600" />
                      <h4 className="text-sm font-bold text-slate-700">การตั้งค่าโฟลเดอร์</h4>
                    </div>
                    <div className="space-y-3">
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-slate-500 ml-1">Google Drive Folder ID หรือ URL</label>
                        <input 
                          type="text"
                          value={certFolderId}
                          onChange={(e) => setCertFolderId(e.target.value)}
                          placeholder="วางลิงก์โฟลเดอร์ Google Drive ที่นี่..."
                          className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm"
                        />
                      </div>
                      <div className="p-3 bg-amber-50 rounded-xl border border-amber-100 flex gap-2">
                        <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                        <p className="text-[11px] text-amber-700 leading-relaxed">
                          * ชื่อไฟล์ในโฟลเดอร์ต้องเป็นลำดับเลขตรงกับลำดับเช็คอิน เช่น <b>1.png, 2.png</b> <br />
                          * ตรวจสอบให้มั่นใจว่าโฟลเดอร์ถูกตั้งค่าแชร์เป็น <b>"ทุกคนที่มีลิงก์ (Anyone with the link)"</b>
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Email Content */}
                  <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200">
                    <div className="flex items-center gap-2 mb-3">
                      <Mail className="w-4 h-4 text-indigo-600" />
                      <h4 className="text-sm font-bold text-slate-700">ข้อความในอีเมล</h4>
                    </div>
                    <div className="space-y-3">
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-slate-500 ml-1">หัวข้ออีเมล (Subject)</label>
                        <input 
                          type="text"
                          value={certEmailSubject}
                          onChange={(e) => setCertEmailSubject(e.target.value)}
                          className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm font-medium"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-slate-500 ml-1">เนื้อหาอีเมล (Body)</label>
                        <textarea 
                          value={certEmailBody}
                          onChange={(e) => setCertEmailBody(e.target.value)}
                          rows={4}
                          className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm resize-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Manual Entry Section */}
                  <div className="bg-indigo-50/50 p-5 rounded-2xl border border-indigo-100">
                    <div className="flex items-center gap-2 mb-3">
                      <Plus className="w-4 h-4 text-indigo-600" />
                      <h4 className="text-sm font-bold text-slate-700">เพิ่มรายชื่อเพิ่มเติม (Manual Entry)</h4>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-400 ml-1">ชื่อ-นามสกุล</label>
                        <input 
                          type="text"
                          placeholder="เช่น อ.สมชาย ใจดี"
                          value={newCustomCertName}
                          onChange={(e) => setNewCustomCertName(e.target.value)}
                          className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-400 ml-1">อีเมล (@bu.ac.th)</label>
                        <input 
                          type="email"
                          placeholder="example@bu.ac.th"
                          value={newCustomCertEmail}
                          onChange={(e) => setNewCustomCertEmail(e.target.value)}
                          className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm"
                        />
                      </div>
                    </div>
                    <button 
                      onClick={() => {
                        if (!newCustomCertName || !newCustomCertEmail) {
                          toast.error("กรุณากรอกทั้งชื่อและอีเมล");
                          return;
                        }
                        if (!newCustomCertEmail.includes("@")) {
                          toast.error("รูปแบบอีเมลไม่ถูกต้อง");
                          return;
                        }
                        const newId = `custom-${Date.now()}`;
                        setCustomCertRecipients(prev => [
                          ...prev, 
                          { id: newId, name: newCustomCertName, email: newCustomCertEmail }
                        ]);
                        setCertSelectedIds(prev => [...prev, newId]);
                        setNewCustomCertName("");
                        setNewCustomCertEmail("");
                        toast.success("เพิ่มรายชื่อเรียบร้อย ลำดับจะรันต่อท้ายคนสุดท้าย");
                      }}
                      className="w-full py-2.5 bg-indigo-600 text-white text-sm font-bold rounded-xl hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
                    >
                      <Plus className="w-4 h-4" />
                      เพิ่มรายชื่อลงในคิวส่ง
                    </button>
                  </div>

                  {/* Recipients Selection */}
                  <div>
                    <div className="flex items-center justify-between mb-3 px-1">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-indigo-600" />
                        <h4 className="text-sm font-bold text-slate-700">รายชื่อผู้ที่มาอบรมจริงและเพิ่มเติม ({certRecipients.length + customCertRecipients.length} คน)</h4>
                      </div>
                      <button 
                        onClick={() => {
                          const allIds = [...certRecipients.map(r => r.id), ...customCertRecipients.map(r => r.id)];
                          if (certSelectedIds.length === allIds.length) setCertSelectedIds([]);
                          else setCertSelectedIds(allIds);
                        }}
                        className="text-xs font-bold text-indigo-600 hover:text-indigo-700"
                      >
                        {certSelectedIds.length === (certRecipients.length + customCertRecipients.length) ? "ไม่เลือกทั้งหมด" : "เลือกทั้งหมด"}
                      </button>
                    </div>
                    <div className="border border-slate-200 rounded-2xl overflow-hidden max-h-[350px] overflow-y-auto bg-white">
                      <table className="w-full text-left text-sm border-collapse">
                        <thead className="bg-slate-50 sticky top-0 z-10 border-b border-slate-200">
                          <tr>
                            <th className="px-4 py-3 font-bold text-slate-500 w-12 text-center">เลือก</th>
                            <th className="px-4 py-3 font-bold text-slate-500 w-24">ลำดับใบประกาศ</th>
                            <th className="px-4 py-3 font-bold text-slate-500">ชื่อ-นามสกุล</th>
                            <th className="px-4 py-3 font-bold text-slate-500">อีเมล</th>
                            <th className="px-4 py-3 font-bold text-slate-500 text-center">จัดการ/สถานะ</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {certRecipients.map((r, index) => {
                            const isSelected = certSelectedIds.includes(r.id);
                            return (
                              <tr 
                                key={r.id} 
                                className={cn(
                                  "hover:bg-slate-50 transition-colors cursor-pointer",
                                  isSelected ? "bg-indigo-50/30" : ""
                                )}
                                onClick={() => handleToggleCertRecipient(r.id)}
                              >
                                <td className="px-4 py-3 text-center">
                                  {isSelected ? (
                                    <CheckSquare className="w-5 h-5 text-indigo-600 mx-auto" />
                                  ) : (
                                    <Square className="w-5 h-5 text-slate-300 mx-auto" />
                                  )}
                                </td>
                                <td className="px-4 py-3 font-black text-indigo-600">{index + 1}</td>
                                <td className="px-4 py-3 font-bold text-slate-700">{formatInstructorName(r.userName)}</td>
                                <td className="px-4 py-3 text-slate-500 text-xs">{r.userEmail}</td>
                                <td className="px-4 py-3 text-center">
                                  {r.certStatus === 'sent' ? (
                                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full text-[10px] font-bold">ส่งแล้ว</span>
                                  ) : r.certStatus === 'failed' ? (
                                    <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-[10px] font-bold">ล้มเหลว</span>
                                  ) : (
                                    <span className="px-2 py-0.5 bg-slate-100 text-slate-500 rounded-full text-[10px] font-bold">ยังไม่ส่ง</span>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                          {customCertRecipients.map((r, index) => {
                            const isSelected = certSelectedIds.includes(r.id);
                            return (
                              <tr 
                                key={r.id} 
                                className={cn(
                                  "hover:bg-indigo-50/50 transition-colors cursor-pointer bg-indigo-50/20",
                                  isSelected ? "bg-indigo-50/50" : ""
                                )}
                                onClick={() => handleToggleCertRecipient(r.id)}
                              >
                                <td className="px-4 py-3 text-center">
                                  {isSelected ? (
                                    <CheckSquare className="w-5 h-5 text-indigo-600 mx-auto" />
                                  ) : (
                                    <Square className="w-5 h-5 text-slate-300 mx-auto" />
                                  )}
                                </td>
                                <td className="px-4 py-3 font-black text-amber-600 italic">
                                  {certRecipients.length + index + 1}
                                </td>
                                <td className="px-4 py-3 font-bold text-slate-700 flex items-center gap-2">
                                  {formatInstructorName(r.name)}
                                  <span className="text-[9px] bg-amber-100 text-amber-700 px-1.5 rounded-full font-bold uppercase">Manual</span>
                                </td>
                                <td className="px-4 py-3 text-slate-500 text-xs">{r.email}</td>
                                <td className="px-4 py-3 text-center">
                                  <button 
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setCustomCertRecipients(prev => prev.filter(p => p.id !== r.id));
                                      setCertSelectedIds(prev => prev.filter(id => id !== r.id));
                                    }}
                                    className="p-1.5 text-slate-400 hover:text-red-500 transition-colors"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ) : (
                /* Step 2: Preview Mode */
                <div className="space-y-6">
                  {/* Folder Validation Result */}
                  <div className="bg-emerald-50 p-5 rounded-2xl border border-emerald-100 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm text-emerald-600">
                        <FileCheck className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-emerald-900">โฟลเดอร์พร้อมใช้งาน</h4>
                        <p className="text-xs text-emerald-700">พบไฟล์ใบเกียรติบัตรครบถ้วนในระบบ</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] text-emerald-600 uppercase font-bold tracking-wider">จำนวนผู้รับที่จะส่ง</p>
                      <p className="text-2xl font-black text-emerald-900">{certSelectedIds.length} <span className="text-xs font-bold">คน</span></p>
                    </div>
                  </div>

                  {/* Summary Table */}
                  <div>
                    <h4 className="text-sm font-bold text-slate-700 mb-3 px-1">สรุปการจับคู่ไฟล์ใบเกียรติบัตร</h4>
                    <div className="border border-slate-200 rounded-2xl overflow-hidden bg-white max-h-[400px] overflow-y-auto">
                      <table className="w-full text-left text-sm border-collapse">
                        <thead className="bg-slate-50 sticky top-0 z-10 border-b border-slate-200">
                          <tr>
                            <th className="px-5 py-3 font-bold text-slate-500">ลำดับไฟล์</th>
                            <th className="px-5 py-3 font-bold text-slate-500">ชื่อผู้รับ</th>
                            <th className="px-5 py-3 font-bold text-slate-500">ระบุชื่อในอีเมล</th>
                            <th className="px-5 py-3 font-bold text-slate-500">อีเมลปลายทาง</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {certRecipients.filter(r => certSelectedIds.includes(r.id)).map(r => {
                            const globalIndex = certRecipients.findIndex(cr => cr.id === r.id);
                            return (
                              <tr key={r.id}>
                                <td className="px-5 py-3">
                                  <span className="bg-slate-100 text-slate-700 px-2 py-1 rounded-lg font-mono text-xs font-bold">{globalIndex + 1}.png</span>
                                </td>
                                <td className="px-5 py-3 font-bold text-slate-700">{formatInstructorName(r.userName)}</td>
                                <td className="px-5 py-3 text-slate-500 italic">เรียน {formatInstructorName(r.userName)}...</td>
                                <td className="px-5 py-3 text-indigo-600 font-medium">{r.userEmail}</td>
                              </tr>
                            );
                          })}
                          {customCertRecipients.filter(r => certSelectedIds.includes(r.id)).map((r, index) => {
                            return (
                              <tr key={r.id} className="bg-indigo-50/20">
                                <td className="px-5 py-3">
                                  <span className="bg-amber-100 text-amber-700 px-2 py-1 rounded-lg font-mono text-xs font-bold">{certRecipients.length + index + 1}.png</span>
                                </td>
                                <td className="px-5 py-3 font-bold text-slate-700">{formatInstructorName(r.name)}</td>
                                <td className="px-5 py-3 text-slate-500 italic">เรียน {formatInstructorName(r.name)}...</td>
                                <td className="px-5 py-3 text-indigo-600 font-medium">{r.email}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="pt-6 border-t border-slate-100 mt-6 flex flex-col sm:flex-row gap-3">
              {!isPreviewMode ? (
                <>
                  <button
                    onClick={() => setShowCertModal(false)}
                    className="flex-1 py-3.5 px-6 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl transition-all"
                  >
                    ยกเลิก
                  </button>
                  <button
                    onClick={handleValidateCertFolder}
                    disabled={certSelectedIds.length === 0 || !certFolderId || isValidatingCert}
                    className="flex-[2] py-3.5 px-6 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-300 text-white font-bold rounded-2xl transition-all shadow-xl shadow-indigo-100 flex items-center justify-center gap-2"
                  >
                    {isValidatingCert ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <Eye className="w-5 h-5" />
                    )}
                    ตรวจสอบโฟลเดอร์และดูตัวอย่าง
                  </button>
                </>
              ) : (
                <>
                  <button
                    disabled={isSendingCerts}
                    onClick={() => setIsPreviewMode(false)}
                    className="flex-1 py-3.5 px-6 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl transition-all"
                  >
                    ย้อนกลับ
                  </button>
                  <button
                    disabled={isSendingCerts}
                    onClick={() => handleSendCertificates(true)}
                    className="flex-1 py-3.5 px-6 bg-amber-100 hover:bg-amber-200 text-amber-700 font-bold rounded-2xl transition-all flex items-center justify-center gap-2"
                  >
                    <Mail className="w-5 h-5" />
                    ส่งทดสอบ (Admin)
                  </button>
                  <button
                    disabled={isSendingCerts}
                    onClick={() => handleSendCertificates(false)}
                    className="flex-[2] py-3.5 px-6 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-300 text-white font-bold rounded-2xl transition-all shadow-xl shadow-emerald-100 flex items-center justify-center gap-2"
                  >
                    {isSendingCerts ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <Send className="w-5 h-5" />
                    )}
                    ยืนยันการส่งให้ทุกคน ({certSelectedIds.length} คน)
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Eval Modal */}
      {showEvalModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            onClick={() => setShowEvalModal(false)}
          />
          <div className="relative bg-white rounded-3xl shadow-2xl p-6 md:p-8 max-w-2xl w-full max-h-[90vh] flex flex-col">
            <button 
              onClick={() => setShowEvalModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 bg-slate-50 hover:bg-slate-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center shrink-0">
                <FileText className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-800">ส่งแบบประเมินผล</h3>
                <p className="text-slate-500 text-sm">ส่งลิงก์แบบประเมินไปยังอีเมลของผู้เข้าอบรม</p>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto pr-2 mb-6 space-y-6">
              
              <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200">
                <h4 className="text-sm font-bold text-amber-800 mb-2 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  URL ของระบบ (สำหรับลิงก์ในอีเมล)
                </h4>
                <p className="text-[11px] text-amber-700 mb-3 leading-relaxed">
                  หากคุณใช้งานระบบผ่าน AI Studio (URL ลับ) ผู้เข้าอบรมที่คลิกลิงก์จะพบข้อความ Error 403 
                  กรุณากรอก URL สาธารณะของระบบที่ผู้ใช้งานเข้าถึงได้จริง (เช่น Netlify หรือ Firebase URL)
                </p>
                <input 
                  type="text"
                  placeholder="https://my-app.netlify.app"
                  value={evalBaseUrl}
                  onChange={(e) => setEvalBaseUrl(e.target.value)}
                  className="w-full px-4 py-2 bg-white border border-amber-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none transition-all text-sm font-mono text-slate-600"
                />
              </div>

              {/* Add Custom Person Section */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <h4 className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-blue-600" />
                  เพิ่มผู้รับอีเมลเอง (เพิ่มเติม)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-400 ml-1">ชื่อ-นามสกุล</label>
                    <input 
                      type="text"
                      placeholder="เช่น อ.สมชาย ใจดี"
                      value={newCustomEvalName}
                      onChange={(e) => setNewCustomEvalName(e.target.value)}
                      className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-400 ml-1">อีเมล (@bu.ac.th)</label>
                    <input 
                      type="email"
                      placeholder="example@bu.ac.th"
                      value={newCustomEvalEmail}
                      onChange={(e) => setNewCustomEvalEmail(e.target.value)}
                      className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm"
                    />
                  </div>
                </div>
                <button 
                  onClick={() => {
                    if (!newCustomEvalName || !newCustomEvalEmail) {
                      toast.error("กรุณากรอกทั้งชื่อและอีเมล");
                      return;
                    }
                    if (!newCustomEvalEmail.includes("@")) {
                      toast.error("รูปแบบอีเมลไม่ถูกต้อง");
                      return;
                    }
                    setCustomEvalRecipients(prev => [
                      ...prev, 
                      { id: Date.now().toString(), name: newCustomEvalName, email: newCustomEvalEmail }
                    ]);
                    setNewCustomEvalName("");
                    setNewCustomEvalEmail("");
                  }}
                  className="w-full py-2 bg-blue-600 text-white text-sm font-bold rounded-xl hover:bg-blue-700 transition-all flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  เพิ่มรายชื่อ
                </button>
              </div>

              {/* Recipients List Section */}
              <div className="space-y-4">
                {/* Custom Recipients */}
                {customEvalRecipients.length > 0 && (
                  <div>
                    <h4 className="text-sm font-bold text-slate-700 mb-2 px-1 flex items-center justify-between">
                      <span>รายชื่อที่เพิ่มเอง ({customEvalRecipients.length})</span>
                      <button 
                        onClick={() => setCustomEvalRecipients([])}
                        className="text-[11px] text-red-500 hover:underline font-bold"
                      >
                        ล้างทั้งหมด
                      </button>
                    </h4>
                    <div className="space-y-2">
                      {customEvalRecipients.map(r => (
                        <div key={r.id} className="flex items-center justify-between p-3 bg-blue-50/50 border border-blue-100 rounded-xl">
                          <div className="flex flex-col">
                            <span className="text-sm font-bold text-slate-700">{r.name}</span>
                            <span className="text-[11px] text-blue-600 font-medium">{r.email}</span>
                          </div>
                          <button 
                            onClick={() => setCustomEvalRecipients(prev => prev.filter(p => p.id !== r.id))}
                            className="p-1.5 text-slate-400 hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Attendees */}
                <div className="bg-blue-50/30 border border-blue-100 p-4 rounded-2xl">
                  <div className="flex items-center justify-between mb-3 px-1">
                    <h4 className="text-sm font-bold text-slate-700">รายชื่อผู้ที่มาอบรมจริง ({evalSelectedIds.length} คน)</h4>
                    <button 
                      onClick={() => {
                        const attendees = registrations.filter(r => r.attended);
                        if (evalSelectedIds.length === attendees.length) setEvalSelectedIds([]);
                        else setEvalSelectedIds(attendees.map(a => a.id));
                      }}
                      className="text-xs font-bold text-blue-600 hover:text-blue-700 bg-white px-3 py-1 rounded-lg border border-blue-100"
                    >
                      {evalSelectedIds.length === registrations.filter(r => r.attended).length ? "ไม่เลือกทั้งหมด" : "เลือกทั้งหมด"}
                    </button>
                  </div>
                  <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
                    {registrations.filter(r => r.attended).map(r => {
                      const isSelected = evalSelectedIds.includes(r.id);
                      return (
                        <div 
                          key={r.id} 
                          className={cn(
                            "flex items-center gap-3 p-3 bg-white rounded-xl border transition-all cursor-pointer",
                            isSelected ? "border-blue-200 shadow-sm" : "border-slate-100 opacity-70"
                          )}
                          onClick={() => handleToggleEvalRecipient(r.id)}
                        >
                          <input 
                            type="checkbox"
                            checked={isSelected}
                            onChange={(e) => {
                              e.stopPropagation();
                              handleToggleEvalRecipient(r.id);
                            }}
                            className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer border-slate-300"
                          />
                          <div className="flex flex-col flex-1">
                            <span className="text-sm font-bold text-slate-700">{formatInstructorName(r.userName)}</span>
                            <span className="text-[11px] text-slate-500">{r.userEmail}</span>
                          </div>
                        </div>
                      );
                    })}
                    {registrations.filter(r => r.attended).length === 0 && (
                      <div className="text-sm text-slate-400 text-center py-10 bg-white rounded-xl border border-slate-100 border-dashed">
                        - ไม่มีผู้เข้าร่วมอบรมที่เช็คอินแล้ว -
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-3 pt-4 border-t border-slate-100 mt-auto">
              <button
                onClick={() => setShowEvalModal(false)}
                className="flex-1 py-3.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl transition-colors"
              >
                ยกเลิก
              </button>
              <button
                onClick={handleSendEvaluations}
                disabled={evalSelectedIds.length === 0 && customEvalRecipients.length === 0}
                className="flex-[2] py-3.5 px-4 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white font-bold rounded-2xl transition-all shadow-xl shadow-blue-100 flex items-center justify-center gap-2"
              >
                <Send className="w-5 h-5" />
                ยืนยันการส่ง ({evalSelectedIds.length + customEvalRecipients.length} คน)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reminder Modal */}
      {showReminderModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            onClick={() => { if (!isSendingReminder) setShowReminderModal(false); }}
          />
          <div className="relative bg-white rounded-3xl shadow-2xl p-6 md:p-8 max-w-5xl w-full max-h-[90vh] flex flex-col overflow-hidden">
            <div className="flex justify-between items-center mb-6 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center">
                  <Bell className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900">ส่งอีเมลแจ้งเตือนก่อนการอบรม</h3>
                  <p className="text-xs text-slate-500 font-medium">ส่งในนาม "สำนักพัฒนาการเรียนรู้" (Office of Learning Development)</p>
                </div>
              </div>
              {!isSendingReminder && (
                <button 
                  onClick={() => setShowReminderModal(false)}
                  className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              )}
            </div>

            <div className="flex-1 overflow-y-auto pr-2">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
                {/* Left Column: Editor */}
                <div className="space-y-4 flex flex-col h-full">
                  <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 flex-1 flex flex-col">
                    <div className="flex items-center gap-2 mb-4">
                      <Mail className="w-4 h-4 text-amber-600" />
                      <h4 className="text-sm font-bold text-slate-700">เนื้อหาอีเมลแจ้งเตือน</h4>
                    </div>
                    <div className="space-y-4 flex-1 flex flex-col">
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-slate-500 ml-1">หัวข้ออีเมล (Subject)</label>
                        <input 
                          type="text"
                          value={reminderSubject}
                          onChange={(e) => setReminderSubject(e.target.value)}
                          className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none transition-all text-sm font-medium"
                        />
                      </div>
                      <div className="space-y-1.5 flex-1 flex flex-col">
                        <label className="text-xs font-semibold text-slate-500 ml-1">เนื้อหาอีเมล (Body)</label>
                        <textarea 
                          value={reminderBody}
                          onChange={(e) => setReminderBody(e.target.value)}
                          className="w-full h-full min-h-[250px] px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none transition-all text-sm resize-none"
                        />
                        <p className="text-[11px] text-slate-400 mt-2">
                          * ส่วนหัวจะขึ้นต้นให้อัตโนมัติด้วย: <b>เรียน คุณ [ชื่อผู้รับ]</b><br/>
                          * ส่วนท้ายจะลงนามปิดให้อัตโนมัติด้วย: <b>สำนักพัฒนาการเรียนรู้ (Learning Development Office) มหาวิทยาลัยกรุงเทพ</b>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right Column: Recipients list */}
                <div className="flex flex-col h-full">
                  <div className="flex items-center justify-between mb-3 px-1">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-amber-600" />
                      <h4 className="text-sm font-bold text-slate-700">ผู้รับอีเมลทั้งหมด ({registrations.length} คน)</h4>
                    </div>
                  </div>
                  <div className="border border-slate-200 rounded-2xl overflow-hidden bg-white max-h-[450px] flex-1 flex flex-col">
                    <div className="overflow-y-auto flex-1 p-3 space-y-2">
                      {registrations.map(r => {
                        const isSelected = reminderSelectedIds.includes(r.id);
                        return (
                          <div 
                            key={r.id} 
                            className={cn(
                              "flex items-center justify-between p-3 rounded-xl border transition-colors",
                              isSelected ? "bg-amber-50/50 border-amber-100" : "bg-slate-50 border-slate-100 opacity-60"
                            )}
                          >
                            <div className="flex flex-col">
                              <span className={cn("text-sm font-bold", isSelected ? "text-slate-800" : "text-slate-500")}>
                                {formatInstructorName(r.userName)}
                              </span>
                              <span className="text-xs text-slate-500">{r.userEmail}</span>
                            </div>
                            <button 
                              onClick={() => handleToggleReminderRecipient(r.id)}
                              className={cn(
                                "flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border",
                                isSelected 
                                ? "bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border-emerald-200 shadow-sm" 
                                : "bg-red-50 text-red-600 hover:bg-red-100 border-red-200"
                              )}
                            >
                              {isSelected ? (
                                <>
                                  <CheckCircle2 className="w-4 h-4" /> ส่งอีเมล
                                </>
                              ) : (
                                <>
                                  <XCircle className="w-4 h-4" /> ไม่ส่ง
                                </>
                              )}
                            </button>
                          </div>
                        );
                      })}
                      {registrations.length === 0 && (
                        <div className="text-center py-10 text-slate-400 text-sm">
                          ไม่มีผู้ลงทะเบียนในหลักสูตรนี้
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="pt-6 border-t border-slate-100 mt-6 flex flex-col sm:flex-row gap-3">
              <button
                disabled={isSendingReminder}
                onClick={() => setShowReminderModal(false)}
                className="flex-1 py-3.5 px-6 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl transition-all"
              >
                ยกเลิก
              </button>
              <button
                disabled={isSendingReminder}
                onClick={() => handleSendReminders(true)}
                className="flex-1 py-3.5 px-6 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-2xl transition-all flex items-center justify-center gap-2 shadow-lg"
              >
                <Mail className="w-5 h-5" />
                ส่งทดสอบ (Admin)
              </button>
              <button
                disabled={isSendingReminder || reminderSelectedIds.length === 0}
                onClick={() => handleSendReminders(false)}
                className="flex-[2] py-3.5 px-6 bg-amber-500 hover:bg-amber-600 disabled:bg-amber-300 text-white font-bold rounded-2xl transition-all shadow-xl shadow-amber-200 flex items-center justify-center gap-2"
              >
                {isSendingReminder ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
                ทำการส่งแจ้งเตือน ({reminderSelectedIds.length} คน)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            onClick={() => setDeleteConfirm(null)}
          />
          <div className="relative bg-white rounded-3xl shadow-2xl p-8 max-w-sm w-full text-center">
            <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-8 h-8 text-red-500" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">ยืนยันการลบ</h3>
            <p className="text-slate-500 mb-8">
              คุณแน่ใจหรือไม่ว่าต้องการลบผู้ลงทะเบียนรายนี้? การกระทำนี้ไม่สามารถย้อนกลับได้
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl transition-colors"
              >
                ยกเลิก
              </button>
              <button
                onClick={confirmDeleteRegistration}
                className="flex-1 py-3 px-4 bg-red-500 hover:bg-red-600 text-white font-medium rounded-xl transition-colors"
              >
                ยืนยันการลบ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Delete Confirmation Modal */}
      {bulkDeleteConfirm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            onClick={() => setBulkDeleteConfirm(false)}
          />
          <div className="relative bg-white rounded-3xl shadow-2xl p-8 max-w-sm w-full text-center">
            <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-8 h-8 text-red-500" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">ยืนยันการลบหลายรายการ</h3>
            <p className="text-slate-500 mb-8">
              คุณแน่ใจหรือไม่ว่าต้องการลบผู้ลงทะเบียนที่เลือกทั้งหมด <b>{selectedRegIds.length} รายการ</b>? การกระทำนี้ไม่สามารถย้อนกลับได้
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setBulkDeleteConfirm(false)}
                className="flex-1 py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl transition-colors"
              >
                ยกเลิก
              </button>
              <button
                onClick={handleBulkDelete}
                className="flex-1 py-3 px-4 bg-red-500 hover:bg-red-600 text-white font-medium rounded-xl transition-colors"
              >
                ยืนยันการลบทั้งหมด
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
